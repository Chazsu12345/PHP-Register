<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['user'];
    $comments = $_POST['comments'];

    try {
     /*
        do your code here
     */
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../index.php");
}
