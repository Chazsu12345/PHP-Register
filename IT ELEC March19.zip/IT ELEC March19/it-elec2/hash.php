<?php

$pwd = '12345567835';
// $pwd = $_POST['pwd];

echo "Password: $pwd<br>";

$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
$option = [
    'cost' => 15
];

// $hashedPwd = password_hash($pwd, PASSWORD_BCRYPT, $option);

echo "Hashed Pwd: $hashedPwd<br>";

$userInputPwd = '12345567835';

$verifyPwd = password_verify($userInputPwd, $hashedPwd);

if($verifyPwd)
    echo "<br>Logged in";
else
    echo "<br>Invalid credentials.";
// echo "<br>Verify: $verifyPwd";

$address = "LOOC, MANDAUE CITY, CEBU, 6014";

echo "<br>" . ucwords($address);

echo "<br><br>" . date('U');

$email = "firstname.lastname@domain.com";

$validEmail = filter_var($email, FILTER_VALIDATE_EMAIL);

echo "<br><br>Valid Email: $validEmail";