<?php
require_once 'config.inc.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $pwd = $_POST["pwd"];
    $email = $_POST["email"];

    if(empty($username)){
        $_SESSION['errors']['username'] = 'Username field is required.';
    }
    if(empty($pwd)){
        $_SESSION['errors']['pwd'] = 'Password field is required.';
    }
    if(empty($email)){
        $_SESSION['errors']['email'] = 'Email field is required.';
    }
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['errors']['email'] = 'Invalid email address format.';
    }

    if(isset($_SESSION['errors'])) {
        header("Location: ../register.php");
        // unset($_SESSION['errors']);
        exit();
    }

    try {
        require_once "dbc.inc.php";

        $query = "INSERT INTO users (username, pwd, email) VALUES (:username, :pwd, :email);";

        $stmt = $pdo->prepare($query);

        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":pwd", $pwd);
        $stmt->bindParam(":email", $email);

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        header("Location: ../index.php");

        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../index.php");
}
