
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "midterm";

try {

    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // set the PDO error mode to exception
    // echo "Connected Successfully";
    
} catch(PDOException $e) {

    echo "Connection Failed" .$e->getMessage();
}

?>


<?php
// Delete query is given but need additional code


session_start();
require_once 'dbc.inc.php';

if(isset($_POST['delete_student']))
{
    $student_id = $_POST['delete_student'];

    try {

        $query = "DELETE FROM students WHERE id=:stud_id";
        $statement = $conn->prepare($query);
        $data = [
            ':stud_id' => $student_id
        ];
        $query_execute = $statement->execute($data);

        if($query_execute)
        {
            $_SESSION['message'] = "Deleted Successfully";
            header('Location: index.php');
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Not Deleted";
            header('Location: index.php');
            exit(0);
        }

    } catch(PDOException $e){
        echo $e->getMessage();
    }
}

// require_once 'dbc.inc.php';
// $firstname = "firstname";

// $sql = "DELETE FROM students WHERE firstname = :firstname;";

// $stmt = $pdo->prepare($sql);

// $stmt->bindParam(':firstname', $firstname);

// $stmt->execute();

// $pdo = null;
// $stmt = null;


// header("Location: ../index.php?delete");
//     die();
?>
